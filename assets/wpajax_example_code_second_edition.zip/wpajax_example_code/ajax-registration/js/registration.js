jQuery(document).ready(function() {
	var $ = jQuery;
	$.registrationform = {
		init: function() {  
			$("#ajax-registration-form").submit(function() {
				//Clear all form errors
				$('#ajax-registration-form input').removeClass('error');
				//Update status message
				$("#registration-status-message").removeClass('error').addClass('success').html('Sending...');
				//Disable submit button
				$('#ajax-submit').attr("disabled", "disabled");
				//Serialize form data
				var form_data = $('#ajax-registration-form input').serializeArray();
				form_data = $.param(form_data);										 
				//Submit ajax request
				$.post( ajaxregistration.Ajax_Url, { action: 'submitajaxregistration', ajax_form_data: form_data, _ajax_nonce: $('#_registration_nonce').val() },
					function(data){
						var res = wpAjax.parseAjaxResponse(data, 'ajax-response');
						if (res.errors) {
							//form errors
							//re-enable submit button
							$('#ajax-submit').removeAttr("disabled");
							var html = '';
							$.each(res.responses, function() {
								$.each(this.errors, function() {
									$("#" + this.code).addClass('error');
									html = html + this.message + '<br />';
								});
							});
							$("#registration-status-message").removeClass('success').addClass('error').html(html);
						} else {
							//no errors	
							$.each(res.responses, function() {
								$("#registration-status-message").addClass('success').html(this.data);
								return;
							});
						}
						
				});
				return false;
			});
		}
	}; //end .registrationform
	$.registrationform.init();
});