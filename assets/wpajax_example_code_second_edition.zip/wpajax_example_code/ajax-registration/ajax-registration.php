<?php
/*
Plugin Name: Ajax Registration
Plugin URI: http://www.ronalfy.com
Description: Allows users to register for your website via Ajax.
Author: Ronald Huereca
Version: 1.0.0.0
Requires at least: 3.0
Author URI: http://www.ronalfy.com

*/ 
class Ajax_Registration {

	//Constructors
	function Ajax_Registration() {
		$this->__construct();
	}
	function __construct() {
		//add scripts
	   add_action( 'wp_print_scripts', array( &$this, 'add_scripts' ) );
	   //add css
	   add_action( 'wp_print_styles', array( &$this, 'add_styles' ) );
	   //ajax
	   add_action( 'wp_ajax_nopriv_submitajaxregistration', array( &$this, 'ajax_process_registration' ) );
	   add_action( 'wp_ajax_submitajaxregistration', array( &$this, 'ajax_process_registration' ) );
	   //when saving a post
	   add_action( 'save_post', array( &$this, 'post_save' ) );
	   //shortcode
	   add_shortcode( 'rform', array( &$this, 'rform_shortcode' ) );
	   
	}
	//Add the registration script to a page
	function add_scripts() {
		if ( is_admin() || !$this->has_shortcode() ) return;
		wp_enqueue_script( 'ajax-registration-js', plugins_url( 'js/registration.js' ,__FILE__ ), array( 'jquery', 'wp-ajax-response' ), '1.0' );
		wp_localize_script( 'ajax-registration-js', 'ajaxregistration', array( 'Ajax_Url' => admin_url( 'admin-ajax.php' ) ) );
	}
	function add_styles() {
		if ( is_admin() || !$this->has_shortcode() ) return;
		wp_enqueue_style( 'ajax-registration-css', plugins_url( 'css/registration.css' ,__FILE__ ) );
	}
	function ajax_process_registration() {		
		//Verify the nonce
		check_ajax_referer( 'submit_ajax-registration' );
		
		//Need registration.php for data validation
		require_once( ABSPATH . WPINC . '/registration.php');
		
		//Get post data
		if ( !isset( $_POST['ajax_form_data'] ) ) die("-1");
		parse_str( $_POST['ajax_form_data'], $form_data );
		
		//Get the form fields
		$firstname = sanitize_text_field( $form_data['firstname'] );
		$lastname = sanitize_text_field( $form_data['lastname'] );
		$username = sanitize_text_field( $form_data['username'] );
		$email = sanitize_text_field( $form_data['email'] );
		
		$error_response = $success_response = new WP_Ajax_Response();
		$errors = new WP_Error();
		
		//Start data validation on firstname/lastname
		//Check required fields
		if ( empty( $firstname ) ) 
			$errors->add( 'firstname', 'You must fill out a first name.', 'firstname' );
		
		if ( empty( $lastname ) ) 
			$errors->add( 'lastname', 'You must fill out a last name.' );
			
		if ( empty( $username ) ) 
			$errors->add( 'username', 'You must fill out a user name.' );
			
		if ( empty( $email ) ) 
			$errors->add( 'email', 'You must fill out an e-mail address.' );
		
		//If required fields aren't filled out, send response	
		if ( count ( $errors->get_error_codes() ) > 0 ) {
			$error_response->add(array(
					'what' => 'errors',
					'id' => $errors
			));
			$error_response->send();
			exit;
		}
		
		//Add usernames we don't want used
		$invalid_usernames = array( 'admin' );
		//Do username validation
		$username = sanitize_user( $username );
		if ( !validate_username( $username ) || in_array( $username, $invalid_usernames ) ) {
			$errors->add( 'username', 'Username is invalid.' );
		}
		if ( username_exists( $username ) ) {
			$errors->add( 'username', 'Username already exists.' );
		}
		
		//Do e-mail address validation
		if ( !is_email( $email ) ) {
			$errors->add( 'email', 'E-mail address is invalid.' );
		}
		if (email_exists($email)) {
			$errors->add( 'email', 'E-mail address is already in use.' );
		}
		
		//If any further errors, send response
		if ( count ( $errors->get_error_codes() ) > 0 ) {
			$error_response->add(array(
					'what' => 'errors',
					'id' => $errors
			));
			$error_response->send();
			exit;
		}
		
		//Everything has been validated, proceed with creating the user
		//Create the user
		$user_pass = wp_generate_password();
		$user = array(
			'user_login' => $username,
			'user_pass' => $user_pass,
			'first_name' => $firstname,
			'last_name' => $lastname,
			'user_email' => $email
		);
		$user_id = wp_insert_user( $user );
		
		/*Send e-mail to admin and new user - 
		You could create your own e-mail instead of using this function*/
		wp_new_user_notification( $user_id, $user_pass );
		
		//Send back a response
		$success_response->add(array(
					'what' => 'object',
					'data' => 'User registration successful.  Please check your e-mail.'
		));
		$success_response->send();		
		exit;	
		
	} //end ajax_process_registration
	//Returns true if a post has the rform shortcode, false if not
	function has_shortcode() {
		global $post;
		if ( !is_object($post) ) return false; 
		if ( get_post_meta( $post->ID, '_ajax_registration', true ) ) 
			return true;
		else
			return false;	
	}
	function post_save( $post_id ) {
		//Retrieve the post object - If a revision, get the original post ID
		$revision = wp_is_post_revision( $post_id );
		if ( $revision )	
			$post_id = $revision;
		$post = get_post( $post_id );
		
		//Perform a test for a shortcode in the post's content
		preg_match('/\[rform[^\]]*\]/is', $post->post_content, $matches); //replace yourshortcode with the name of your shortcode
		
		
		if ( count( $matches ) == 0 ) {
			delete_post_meta( $post_id, '_ajax_registration' );
		} else {
			update_post_meta( $post_id, '_ajax_registration', '1' );
		}
	} //end post_save
	function rform_shortcode( ) {
		$return = "<form id='ajax-registration-form'>";
		$return .= wp_nonce_field( 'submit_ajax-registration', '_registration_nonce', true, false );
		$return .= "<ul id='ajax-registration-list'>";                  
		$return .= "<li><label for='firstname'>First name: </label><input type='text' size='30' name='firstname' id='firstname' /></li>";
		$return .= "<li><label for='lastname'>Last name: </label><input type='text' size='30' name='lastname' id='lastname' /></li>";
		$return .= "<li><label for='username'>Desired Username: </label><input type='text' size='30' name='username' id='username' /></li>";
		$return .= "<li><label for='email'>E-mail Address: </label><input type='text' size='30' name='email' id='email' /></li>";
		$return .= "<li><input type='submit' value='Submit Registration' name='ajax-submit' id='ajax-submit' /></li>";
		$return .= "<li id='registration-status-message'></li>";
		$return .= "</ul>";
		$return .= "</form>";
		
		return $return;
	}
	
} //end class
//Instantiate
$ajaxregistration = new Ajax_Registration();
?>