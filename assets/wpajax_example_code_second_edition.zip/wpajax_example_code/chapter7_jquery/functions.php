<?php
add_action('wp_print_scripts', 'my_theme_js_init');
function my_theme_js_init() {
	if (is_admin()) return;
	wp_enqueue_script('my_theme_init', get_stylesheet_directory_uri() . '/init.js', array('jquery'));
}
?>