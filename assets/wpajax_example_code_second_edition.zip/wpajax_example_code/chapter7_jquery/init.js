jQuery(document).ready(function() {
	var $ = jQuery;
	$. my_script_namespace = {
		init: function() { 
			alert("Initializing");
		},
		my_function: function(obj) { /*do some stuff*/ 
		_my_function($(obj));},
		vars: {}
	}; //end my_script_namespace
	//Private variables/functions are declared outside of the namespace
	var myvars = $.my_script_namespace.vars; //private variable
	function _my_function(obj) { /*private function*/
		//my private code here
	}
	$.my_script_namespace.init();
});
//Used to call your namespace from an external script
jQuery(document).ready(function() {
	jQuery.my_script_namespace.init();
});
