jQuery(document).ready(function() {
var $ = jQuery;
$.get_my_comments = {
	init: function() { 
		$("a#get-comments").bind("click", function() {
		  _do_ajax(this); //Call to our private function																				 
			return false;																					 
		});
	}
}; //End of get_my_comments namespace
function _do_ajax(obj) {
	var element = $(obj); //our link object
	var url = wpAjax.unserialize(element.attr('href'));
	var s = {};
	s.response = 'ajax-response';
	s.type = "POST";
	s.url = mythemegetcomments.ajax_url;
	s.data = $.extend(s.data, { action: url.action, _ajax_nonce: url._wpnonce });
	s.global = false;
	s.timeout = 30000;
	s.success = function(r) {
		var res = wpAjax.parseAjaxResponse(r,this.response);
		$.each( res.responses, function() { 
			switch(this.what) {
				case "getcomments":
					var moderation_count = this.supplemental.awaiting_moderation;
					var approved_count = this.supplemental.approved;
					var spam_count = this.supplemental.spam;
					var trashed_count = this.supplemental.trashed;
					
					//Strings
					var moderation = mythemegetcomments.you_have + " " + moderation_count + " " + mythemegetcomments.comments + " " + mythemegetcomments.in_moderation + ".<br />";
					
					var approved = mythemegetcomments.you_have + " " + approved_count + " " + mythemegetcomments.approved + " " + mythemegetcomments.comments + ".<br />";
					
					var spam = mythemegetcomments.you_have + " " + spam_count + " " + mythemegetcomments.spam + " " + mythemegetcomments.comments + ".<br />";
					
					var trashed = mythemegetcomments.you_have + " " + trashed_count + " " + mythemegetcomments.trashed + " " + mythemegetcomments.comments + ".";
					$("div#get-comments-output").html(moderation + approved + spam + trashed);
					break;
				case "something else":
					break;
				default:
					break;
			}//end switch
		});//end each
	} //End success
	s.error = function(r) {
		alert("Epic Fail!");
	}
	$.ajax(s);
} //end _do_ajax
$.get_my_comments.init();
});