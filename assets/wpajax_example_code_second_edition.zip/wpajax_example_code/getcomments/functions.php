<?php
if (!class_exists('myThemeClass')) {
	class myThemeClass	{
		/**
		* PHP 4 Compatible Constructor
		*/
		function myThemeClass(){$this->__construct();}
		/**
		* PHP 5 Constructor
			*/		
		function __construct(){
			add_action('wp_print_scripts', array(&$this,'add_scripts'));
			add_action('init', array(&$this, 'init'));
		}
		function init() {
			load_theme_textdomain('get-comments');
		}
		function get_comments() {
			return wp_count_comments();
			/*wp_count_comments returns an object with values of trash, spam, approved, and moderated*/
		}
		function add_scripts() {
			if (is_admin()) return;
			wp_enqueue_script('my_script', get_stylesheet_directory_uri() .'/my_script.js', array("jquery", "wp-ajax-response") , "2.3");
			wp_localize_script( 'my_script', 'mythemegetcomments', $this->get_js_vars());
		}//End add_scripts
		function get_js_vars() {
			return array(
				'ajax_url' => site_url('?my_page=ajax-processor'),
				'you_have' => __('You have', 'get-comments'),
				'approved' => __('approved', 'get-comments'),
				'comments' => __('comments', 'get-comments'),
				'in_moderation' => __('in moderation', 'get-comments'),
				'trashed' => __('trashed', 'get-comments'),
				'spam' => __('spam', 'get-comments')				
			);
		} //end get_js_vars
		function load_page() {
			$pagepath = STYLESHEETPATH . '/';
			switch(get_query_var('my_page')) {
				case 'ajax-processor':
					if (file_exists($pagepath . 'ajax-processor.php'))
						include($pagepath . 'ajax-processor.php');
					else
						header("HTTP/1.0 404 Not Found");
					exit;
				default:
					break;
			}
		} //end function load_page
		function query_trigger($queries) {
			array_push($queries, 'my_page');
			return $queries;
		}//end function query_trigger
	} //End Class myPluginClass
}
//instantiate the class
if (class_exists('myThemeClass')) {
		$myClassVar = new myThemeClass();
		add_action('template_redirect', array(&$myClassVar,'load_page'));
		add_filter('query_vars', array(&$myClassVar,'query_trigger'));
}
?>