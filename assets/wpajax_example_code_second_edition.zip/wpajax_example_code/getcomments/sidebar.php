<?php
$link_url = wp_nonce_url( site_url('?my_page=ajax-processor&action=getcomment'), "my-theme_getcomment");
?>
<a href='<?php echo $link_url; ?>' id='get-comments'><?php _e('Get Comments','get-comments');?></a>
<div id="get-comments-output"></div>