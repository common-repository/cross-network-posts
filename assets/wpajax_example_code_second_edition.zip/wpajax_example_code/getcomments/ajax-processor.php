<?php 
header('Content-Type: text/html; charset=UTF-8');
define('DOING_AJAX', true);
//Check the AJAX nonce

check_ajax_referer('my-theme_getcomment');

if (isset($_POST['action'])) {
	$action = $_POST['action'];
	switch($action) {
		case 'getcomment':
			$comment_count = $this->get_comments();
			$response = new WP_Ajax_Response();
			$response->add(array(
				'what' => 'getcomments',
				'supplemental' => array(
					'awaiting_moderation' => number_format($comment_count->moderated),
					'approved' => number_format($comment_count->approved),
					'spam' => number_format($comment_count->spam),
					'trashed' => number_format($comment_count->trash)
				)
			));
			$response->send();
			break;
		case 'otheraction':
			break;
		default:
			break;
	}//end switch
} //end if
die('');
?>