<?php 
add_action('wp_print_scripts', 'paypal_add_scripts');
function paypal_add_scripts() {
	if (is_page('purchase')) {
		wp_enqueue_script('paypal_script', get_bloginfo('template_url') . '/paypal.min.js', array('jquery','wp-ajax-response'),'1.0');
		wp_localize_script( 'paypal_script', 'paypalscriptvars', array('ThemeURL' =>  get_bloginfo('template_url')));
	}
}
?>