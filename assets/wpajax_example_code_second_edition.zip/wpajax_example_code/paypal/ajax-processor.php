<?php
header('Content-Type: text/html');
define('WP_INSTALLING', true);
$root = dirname(dirname(dirname(dirname(__FILE__))));
if (file_exists($root.'/wp-load.php')) {
		// WP 2.6
		require_once($root.'/wp-load.php');
} else {
		// Before 2.6
		require_once($root.'/wp-config.php');
}
//Some sanity checks
if (!isset($_POST)) die('');
if (!preg_match('/^[0-9]+$/', $_POST['id']) || (!empty($_POST['coupon']) && !preg_match('/^[0-9A-Za-z]+$/', $_POST['coupon']))) {
	die('');
}
$table = array('100' => array(
							'size' => 'small',
							'price' => '10.00'
						),
						'101' => array(
							'size' => 'medium',
							'price' => '15.00'
						),
						'102' => array(
							'size' => 'large',
							'price' => '20.00'
						)
); 
$result = $table[$_POST['id']];
$size = $result['size'];
$price = $result['price'];

//Check coupons
$coupon = strtoupper($_POST['coupon']);
$coupons = array('BLOWOUT' => '75', 'BIGSALE' => '50');
$discount_percentage = '0';
if (!empty($coupon)) {
	if (!array_key_exists($coupon,$coupons)) {
		$response = new WP_Ajax_Response();
		$response->add(array(
				'what' => 'error',
				'data' => 'Invalid Code'
		));
		$response->send();
		die('');
	} else {
		$discount_percentage = $coupons[$coupon];
	}
}
//PayPal cert stuff
$certificates_path = "/home/user/certificates/";
$public_cert_id = '13098sdfljdf0980';
$public_cert_path = $certificates_path . "pubcert.pem"; 
$private_key_path = $certificates_path . "prvkey.pem";
$paypal_cert_path = $certificates_path . "paypal_cert_pem.txt";

if (!file_exists($public_cert_path) || !file_exists($private_key_path) || !file_exists($paypal_cert_path)) {
	die('');
}

//OpenSSL
$openSSL_path = "/usr/bin/openssl";

//The paypal array
$paypal_args = array('cmd' => '_xclick',
			'business' => 'youremail@gmail.com',
			'notify_url' => 'http://www.yourdomain.com/paypal/listener.php',
			'amount' => $price,
			'discount_rate' => $discount_percentage,
			'item_name' => "My Awesome t-shirt - " . $size,
			'item_number' => $_POST['id'],
			'quantity' => 1,
			'return' => 'http://www.yourdomain.com/success/',
			'cancel_return' => 'http://www.yourdomain.com/error/',
			'cert_id' => $public_cert_id,
			'bn' => 'PP-BuyNowBF:btn_buynowCC_LG.gif:NonHosted',
			'rm' => 2
		);
//Begin retrieving encrypted data
$data = "";
foreach ($paypal_args as $key => $value) {
	if ($value != "") {
		$data .= "$key=$value\n";
	}
}
$openssl_cmd = "($openSSL_path smime -sign -signer $public_cert_path -inkey $private_key_path " .
					"-outform der -nodetach -binary <<_EOF_\n$data\n_EOF_\n) | " .
					"$openSSL_path smime -encrypt -des3 -binary -outform pem $paypal_cert_path";
exec($openssl_cmd, $output, $error);
if (!$error) {
	$output = implode("\n",$output);
	$response = new WP_Ajax_Response();
	$response->add(array(
			'what' => 'paypal_data',
			'data' => $output
	));
	$response->send();
	die('');
} else {
	return "ERROR: NR $error";
}
?>