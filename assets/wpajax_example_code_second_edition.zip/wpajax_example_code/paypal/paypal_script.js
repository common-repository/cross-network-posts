jQuery(document).ready(function() {
	var $ = jQuery;
	$.paypalscript = {
		init: function() {  
$("#paypal_submit").bind("click", function() {
	//Capture UI variables
	var selected = $("select[name='sizes'] option:selected").attr("value");
	var coupon = $.trim($("input[name='couponcode']").attr("value"));
	var ajax = {};
	ajax.element = $(this);
	ajax.response = 'ajax-response';
	ajax.type = "POST";
	ajax.url = paypalscriptvars.ThemeURL + "/ajax-processor.php";
	ajax.data = $.extend(ajax.data, { coupon:coupon,id: selected});
	ajax.global = false;
	ajax.timeout = 30000;
	ajax.success = function(r) {
		var res = wpAjax.parseAjaxResponse(r, this.response,this.element);
		$.each( res.responses, function() {
			//Prepare for the responses
			switch(this.what) {
			case "error":
				$("input[name='couponcode']").after("&nbsp;&nbsp;<span style='color: red; font-weight: bold'>" + this.data + "</span>")
				return;
				break;
			case "paypal_data":
				$("input[name='encrypted']").attr("value",this.data);
				$("#paypal_submit").unbind("click");
				$("#paypal_submit").trigger("click");
				return;
				break;
			}//end switch
		}); //end each
	};
	$.ajax(ajax);
	return false;
});
		}
	};
	$.paypalscript.init();
});