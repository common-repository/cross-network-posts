<?php
if (!class_exists('myThemeClass')) {
	class myThemeClass	{
		/**
		* PHP 4 Compatible Constructor
		*/
		function myThemeClass(){$this->__construct();}
		/**
		* PHP 5 Constructor
			*/		
		function __construct(){
			add_action('wp_print_scripts', array(&$this,'add_scripts'));
			add_action('init', array(&$this, 'init'));
			add_action('wp_ajax_getcomment', array(&$this, 'ajax_get_comments'));
			add_action('wp_ajax_nopriv_getcomment', array(&$this, 'ajax_get_comments'));
		}
		function ajax_get_comments() {
			check_ajax_referer('my-theme_getcomment');
			$comment_count = $this->get_comments();
			$response = new WP_Ajax_Response();
			$response->add(array(
				'what' => 'getcomments',
				'supplemental' => array(
					'awaiting_moderation' => number_format($comment_count->moderated),
					'approved' => number_format($comment_count->approved),
					'spam' => number_format($comment_count->spam),
					'trashed' => number_format($comment_count->trash)
				)
			));
			$response->send();
			exit;		
		} //end ajax_get_comments
		function init() {
			load_theme_textdomain('get-comments');
		}
		function get_comments() {
			return wp_count_comments();
			/*wp_count_comments returns an object with values of trash, spam, approved, and moderated*/
		}
		function add_scripts() {
			if (is_admin()) return;
			wp_enqueue_script('my_script', get_stylesheet_directory_uri() .'/my_script.js', array("jquery", "wp-ajax-response") , "2.3");
			wp_localize_script( 'my_script', 'mythemegetcomments', $this->get_js_vars());
		}//End add_scripts
		function get_js_vars() {
			return array(
				'ajax_url' => admin_url('admin-ajax.php'),
				'you_have' => __('You have', 'get-comments'),
				'approved' => __('approved', 'get-comments'),
				'comments' => __('comments', 'get-comments'),
				'in_moderation' => __('in moderation', 'get-comments'),
				'trashed' => __('trashed', 'get-comments'),
				'spam' => __('spam', 'get-comments')				
			);
		} //end get_js_vars
	} //End Class myPluginClass
}
//instantiate the class
if (class_exists('myThemeClass')) {
		$myClassVar = new myThemeClass();
}
?>