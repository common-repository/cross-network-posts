<?php
$link_url = esc_url(wp_nonce_url( admin_url('admin-ajax.php?action=getcomment'), "my-theme_getcomment"));
?>
<a href='<?php echo $link_url; ?>' id='get-comments'><?php _e('Get Comments','get-comments');?></a>
<div id="get-comments-output"></div>