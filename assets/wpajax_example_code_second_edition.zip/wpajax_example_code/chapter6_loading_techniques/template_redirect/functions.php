<?php
add_action('template_redirect', 'load_page');
add_filter('query_vars', 'query_trigger');

function load_page() {
	$pagepath = WP_CONTENT_DIR . '/themes/my-theme-dir/';
	switch(get_query_var('my_page')) {
		case 'help.php':
			include($pagepath . 'help.php');
			exit;
		case 'changelog.php':
			include($pagepath . 'changelog.php');
			exit;
		default:
			break;
	}
}
function query_trigger($queries) {
	array_push($queries, 'my_page');
	return $queries;
}
?>